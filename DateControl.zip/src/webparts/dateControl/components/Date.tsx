import * as React from 'react';
import {
    DatePicker,
    defaultDatePickerStrings,
    Dropdown,
    IDropdownOption,
    IStackTokens,
    Stack,
} from '@fluentui/react';

const stackTokens: IStackTokens = {
    childrenGap: 5,
    padding: 10,
};

const hoursDropDownOption: IDropdownOption[] = [
    { text: '01', key: "01" },
    { text: '02', key: "02" },
    { text: '03', key: "03" },
    { text: '04', key: "04" },
    { text: '05', key: "05" },
    { text: '06', key: "06" },
    { text: '07', key: "07" },
    { text: '08', key: "08" },
    { text: '09', key: "09" },
    { text: '10', key: "10" },
    { text: '11', key: "11" },
    { text: '12', key: "12" },
];

const mins: IDropdownOption[] = [
    { text: '00', key: "00" },
    { text: '15', key: "15" },
    { text: '30', key: "30" },
    { text: '45', key: "45" }
];

const hourType: IDropdownOption[] = [
    { text: 'AM', key: "AM" },
    { text: 'PM', key: "PM" },
];

export interface IDateTime {
    date: Date;
    label: string;
    hideLabel?: boolean;
    minimum?: Date;
    onDateChange: Function
}

export const DateTime: React.FunctionComponent<IDateTime> = (props) => {
    const [selectedDate, setSelectedDate] = React.useState<Date>(props.date);
    const [selectedHour, setSelectedHour] = React.useState("0");
    const [selectedMin, setSelectedMin] = React.useState("0");
    const [minimumMin, setMinimumMin] = React.useState<number | undefined>(undefined);
    const [minimumHrs, setMinimumHrs] = React.useState<number | undefined>(undefined);
    const [selectedHourType, setSelectedHourType] = React.useState("AM");
    const [hrsOptions, setHrsOptions] = React.useState(hoursDropDownOption);
    
    React.useEffect(() => {
        props.onDateChange(selectedDate,props.label)
    }, [selectedDate]);

    React.useEffect(() => { 
        const {date, minimum} = props;
        let hours = date.getHours(); 
        const min = date.getMinutes();  
        if (hours > 12) {
            hours = hours - 12; 
            setSelectedHourType("PM")
        } else if(hours ===12 ) {
            setSelectedHourType("PM")
        } else if(hours===0) {
            hours = 12;
            setSelectedHourType("AM")
        } else { 
            setSelectedHourType("AM")
        } 
        setSelectedHour(hours < 10 ? "0" + hours : hours.toString())
        setSelectedMin(min < 10 ? "0" + min : min.toString())
        setSelectedDate(date); 
        // setSelectedHourType(props.date.)
    }, [props.date]);

    React.useEffect(()=>{
        if(props.minimum) {
            const minHrs = props.minimum.getHours()
            setMinimumHrs(minHrs)
            const updatedHrsOptions = hoursDropDownOption.map(x=>{
                if(minHrs>parseInt(x.key as string)) {
                    return {...x, disabled: true}
                }
                return x;
            });
            setHrsOptions(updatedHrsOptions);
            // setMinimumMin(minimum.getMinutes())  
        }
    },[props.minimum])

    const updateDateCollection = (selectedHour: number, selectedMin: number) => {
        const updatedHour = updateHourState(selectedHour, selectedHourType, selectedDate) 
        const updatedDate = new Date(selectedDate.toLocaleString());
        updatedDate.setMinutes(selectedMin);
        updatedDate.setHours(updatedHour);
        setSelectedDate(updatedDate)
    }

    const updateHourState = (selectedHour: number, selectedHourType: string, selectedDate: Date) => {
        if (selectedHourType === "AM") {
            if (selectedHour > 12) {
                selectedHour = selectedHour - 12;
            } else if (selectedHour === 12) {
                selectedHour = 0; 
            }
        }
        else if (selectedHourType === "PM" && selectedHour < 12) {
            selectedHour = selectedHour + 12;
        }
        return selectedHour;
        // selectedDate.setHours(selectedHour)
    }

    return (
        <>
            <Stack horizontal tokens={stackTokens}>
                <li>Date:{`${props.label} ${props.date.toLocaleDateString()} ${props.date.toLocaleTimeString()}`}  </li>
            </Stack>
            <Stack horizontal tokens={stackTokens}>
                <li>Date: {props.minimum?.toLocaleDateString()} {props.minimum?.toLocaleTimeString()}</li>
            </Stack>
            <Stack horizontal tokens={stackTokens}>
                <DatePicker
                    placeholder="Select a date..."
                    ariaLabel="Select a date"
                    strings={defaultDatePickerStrings}
                    value={selectedDate}
                    onSelectDate={(newDate) => {
                        const updatedHrs = updateHourState(parseInt(selectedHour), selectedHourType, newDate)
                        newDate.setHours(updatedHrs);
                        newDate.setMinutes(parseInt(selectedMin as string))
                        setSelectedDate(newDate)
                    }}
                    minDate={props.minimum}
                    style={{minWidth: 250}}
                />

                <Dropdown
                    options={hrsOptions}
                    selectedKey={selectedHour}
                    onChange={(e: any, option: IDropdownOption) => {
                        setSelectedHour(option.key as string);
                        updateDateCollection(parseInt(option.key as string), parseInt(selectedMin as string))
                    }}
                    defaultSelectedKey={selectedHour}
                />
                <Dropdown
                    options={mins}
                    selectedKey={selectedMin}
                    onChange={(e: any, option: IDropdownOption) => {
                        setSelectedMin(option.key as string);
                        updateDateCollection(parseInt(selectedHour as string), parseInt(option.key as string))
                    }}
                    defaultSelectedKey={selectedMin}
                />

                <Dropdown
                    options={hourType}
                    selectedKey={selectedHourType}
                    onChange={(event: React.FormEvent<HTMLDivElement>, option: IDropdownOption) => {
                        setSelectedHourType(option.key as string)
                        const updatedHrs = updateHourState(parseInt(selectedHour), option.key as string, selectedDate);
                        const updatedDate = new Date(selectedDate.toLocaleString());
                        updatedDate.setMinutes(parseInt(selectedMin));
                        updatedDate.setHours(updatedHrs)
                        setSelectedDate(updatedDate)
                    }}
                />
            </Stack>
        </>

    );
};