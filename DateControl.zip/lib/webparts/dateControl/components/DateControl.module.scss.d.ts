declare const styles: {
    dateControl: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=DateControl.module.scss.d.ts.map