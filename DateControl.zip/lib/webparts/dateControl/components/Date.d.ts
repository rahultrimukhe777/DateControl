import * as React from 'react';
export interface IDateTime {
    date: Date;
    label: string;
    hideLabel?: boolean;
    minimum?: Date;
    onDateChange: Function;
}
export declare const DateTime: React.FunctionComponent<IDateTime>;
//# sourceMappingURL=Date.d.ts.map