import * as React from 'react';
import styles from './DateControl.module.scss';
import { IDateControlProps } from './IDateControlProps'; 
import {DateTime} from './Date';
export const DateControl = (props:IDateControlProps) => { 
  const [selectedStartDate, setSelectedStartDate] = React.useState<Date>(new Date());
  const [selectedEndDate, setSelectedEndDate] = React.useState<Date>(new Date());

  const { 
    hasTeamsContext, 
  } = props;

  selectedEndDate.setSeconds(0);

  const onDateChange = (date: Date, dateType: string ) => {
    console.log(date, selectedStartDate);
    if(dateType==="Start Date") {
      const newEndDate = new Date(date.toLocaleString());
      newEndDate.setMinutes(date.getMinutes()+15);
      setSelectedStartDate(date); 
      setSelectedEndDate(newEndDate);
    } else {
      setSelectedEndDate(date)
    }
  }

  React.useEffect(()=>{
    console.log("Start Date Changed", selectedStartDate)
  },[selectedStartDate])

  return (
    <section className={`${styles.dateControl} ${hasTeamsContext ? styles.teams : ''}`}>
      <DateTime date={selectedStartDate} onDateChange={onDateChange} label="Start Date"/>
      <DateTime date={selectedEndDate} minimum={selectedStartDate} onDateChange={onDateChange} label="End Date"/>
    </section>
  );

}
