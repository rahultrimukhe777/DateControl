export interface IDateControlProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IDateControlProps.d.ts.map