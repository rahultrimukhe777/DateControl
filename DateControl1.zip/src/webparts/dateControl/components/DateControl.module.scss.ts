/* tslint:disable */
require("./DateControl.module.css");
const styles = {
  dateControl: 'dateControl_5639434e',
  teams: 'teams_5639434e',
  welcome: 'welcome_5639434e',
  welcomeImage: 'welcomeImage_5639434e',
  links: 'links_5639434e'
};

export default styles;
/* tslint:enable */