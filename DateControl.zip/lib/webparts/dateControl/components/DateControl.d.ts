/// <reference types="react" />
import { IDateControlProps } from './IDateControlProps';
export declare const DateControl: (props: IDateControlProps) => JSX.Element;
//# sourceMappingURL=DateControl.d.ts.map